#!/system/bin/sh
/data/local/bin/mount -o suid,remount /data
